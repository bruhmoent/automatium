import { Card } from "./card";

export class Cards {
    cards1: Array<Card> = new Array<Card>();
}